/**
 * 
 */
/**
 * 
 */
module usingJmeterAndJProfilerTogetherDemo {
	requires jdk.httpserver;
}