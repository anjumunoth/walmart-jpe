package usingJmeterAndJProfilerTogetherDemo;

//RequestProcessor.java
public class RequestProcessor implements EventListener {
 // This large array is here to make the memory leak obvious and fast.
 private final byte[] largeMemoryFootprint = new byte[10 * 1024 * 1024]; // 10 MB
 private final String requestId;

 public RequestProcessor(String requestId, NotificationService notificationService) {
     this.requestId = requestId;
     // The fateful subscription. The RequestProcessor gives a reference of itself
     // to the long-lived NotificationService.
     notificationService.subscribe("REQUEST_COMPLETE", this);
 }

 @Override
 public void onEvent(String eventData) {
     // In a real app, this might update some state.
     // System.out.println("RequestProcessor " + requestId + " received event: " + eventData);
 }

 // Crucially, there's no call to an 'unsubscribe' method when this object is done.
}