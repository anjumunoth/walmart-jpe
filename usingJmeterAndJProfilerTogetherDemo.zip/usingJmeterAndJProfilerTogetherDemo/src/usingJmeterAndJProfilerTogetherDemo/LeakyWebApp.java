package usingJmeterAndJProfilerTogetherDemo;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class LeakyWebApp {

    // The long-lived service that will hold the leaky references.
    private final NotificationService notificationService = new NotificationService();

    public static void main(String[] args) throws IOException {
        LeakyWebApp app = new LeakyWebApp();
        app.startServer();
    }

    public void startServer() throws IOException {
        // Create an HTTP server on port 8080
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

        // Create a context for our leaky endpoint
        server.createContext("/create-leak", new LeakHandler());

        server.setExecutor(null); // Use a default executor
        System.out.println("Leaky Web Server started on port 8080.");
        System.out.println("Endpoint available at http://localhost:8080/create-leak");
        System.out.println("The application is now waiting for requests...");
        server.start();
    }

    // This handler contains the logic that will be executed for each request.
    class LeakHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // THE CORE LEAKY ACTION: Create a new processor for every request.
            // This object is supposed to be short-lived but will leak.
            new RequestProcessor(notificationService);

            // Send a simple "OK" response back to the client (JMeter)
            String response = "Leaky object created.";
            exchange.sendResponseHeaders(200, response.length());
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response.getBytes());
            }
        }
    }
}