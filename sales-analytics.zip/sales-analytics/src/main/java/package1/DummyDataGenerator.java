package package1;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class DummyDataGenerator {
 public static void generate(String filePath, int numTransactions, int numProducts) {
     System.out.println("Generating dummy data file: " + filePath);
     try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
         for (int i = 0; i < numTransactions; i++) {
             String transactionId = UUID.randomUUID().toString();
             String customerId = "cust_" + ThreadLocalRandom.current().nextInt(1, 1000);
             String productId = "prod_" + ThreadLocalRandom.current().nextInt(1, numProducts + 1);
             double amount = ThreadLocalRandom.current().nextDouble(5.0, 500.0);
             writer.printf("%s,%s,%s,%.2f\n", transactionId, customerId, productId, amount);
         }
     } catch (IOException e) { e.printStackTrace(); }
 }
}