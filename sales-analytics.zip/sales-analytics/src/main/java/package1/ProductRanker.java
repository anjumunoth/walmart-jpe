package package1;

import java.util.List;

public class ProductRanker {
    // This method has a computationally expensive algorithm.
    public void calculateAffinityScores(List<Transaction> transactions) {
        System.out.println("   -> Analyzing " + transactions.size() + " transactions to find product affinities...");
        // O(n^2) complexity: compares every transaction with every other transaction.
        for (int i = 0; i < transactions.size(); i++) {
            for (int j = 0; j < transactions.size(); j++) {
                if (i == j) continue;
                
                Transaction t1 = transactions.get(i);
                Transaction t2 = transactions.get(j);

                // Simulate a complex calculation
                if (t1.getCustomerId().equals(t2.getCustomerId()) && !t1.getProductId().equals(t2.getProductId())) {
                    Math.pow(t1.getAmount() * t2.getAmount(), 5);
                }
            }
        }
    }
}