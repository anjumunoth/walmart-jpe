package package1;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class SalesAnalyticsApplication {
    public static void main(String[] args) throws Exception {
        System.out.println("Starting TrendSpotter Sales Analytics Platform...");
        System.out.println("PID: " + ProcessHandle.current().pid());

        // First, generate some test data
        DummyDataGenerator.generate("sales-data.csv", 10000, 500);

        // Create services
        DataProcessingService dataService = new DataProcessingService();
        ReportGenerator reportGenerator = new ReportGenerator();

        // Run the main data processing task
        dataService.processSalesData("sales-data.csv");

        // Simulate multiple departments trying to get the summary report at the same time
        System.out.println("Multiple threads requesting summary report...");
        ExecutorService reportPool = Executors.newFixedThreadPool(5);
        for (int i = 0; i < 5; i++) {
            reportPool.submit(() -> {
                System.out.println(Thread.currentThread().getName() + " is generating a report.");
                reportGenerator.generateDailySummary();
                System.out.println(Thread.currentThread().getName() + " finished generating a report.");
            });
        }

        reportPool.shutdown();
        reportPool.awaitTermination(1, TimeUnit.MINUTES);

        System.out.println("Analytics run finished.");
    }
}