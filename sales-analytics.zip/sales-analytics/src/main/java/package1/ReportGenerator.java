package package1;

public class ReportGenerator {
    // This entire method is synchronized, causing threads to wait for each other.
    public synchronized void generateDailySummary() {
        System.out.println("   -> " + Thread.currentThread().getName() + " acquired lock and is generating summary.");
        try {
            // Simulate a long-running, resource-intensive operation like writing to a slow disk.
            Thread.sleep(5000); 
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("   -> " + Thread.currentThread().getName() + " released lock.");
    }
}