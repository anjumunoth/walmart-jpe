package package1;

import java.util.List;

//Well-written orchestration service.
public class DataProcessingService {
 private final SalesDataParser parser = new SalesDataParser();
 private final ProductRanker ranker = new ProductRanker();

 public void processSalesData(String filePath) {
     System.out.println("1. Starting to parse sales data from " + filePath);
     List<Transaction> transactions = parser.parseTransactions(filePath);
     System.out.println("   -> Parsed " + transactions.size() + " transactions.");

     System.out.println("2. Starting product ranking calculation...");
     ranker.calculateAffinityScores(transactions);
     System.out.println("   -> Finished product ranking.");
 }
}