package package1;

public class ProductDetail {
	 private final String id;
	 private final String name;
	 private final byte[] detailBlob;
	 public ProductDetail(String id, String name, byte[] detailBlob) {
	     this.id = id;
	     this.name = name;
	     this.detailBlob = detailBlob;
	 }
	}
