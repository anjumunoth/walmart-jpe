package package1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SalesDataParser {
    public List<Transaction> parseTransactions(String filePath) {
        List<Transaction> transactions = new ArrayList<>();
        File file = new File(filePath);
        StringBuilder currentLine = new StringBuilder();

        try (FileInputStream fis = new FileInputStream(file)) {
            int byteData;
            // Reading file byte-by-byte, which is very inefficient.
            while ((byteData = fis.read()) != -1) {
                if ((char) byteData == '\n') {
                    transactions.add(Transaction.fromCsvLine(currentLine.toString()));
                    currentLine.setLength(0);
                } else {
                    currentLine.append((char) byteData);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return transactions;
    }
}