package package1;

public class Transaction {
 private final String transactionId;
 private final String customerId;
 private final String productId;
 private final double amount;

 public Transaction(String transactionId, String customerId, String productId, double amount) {
     this.transactionId = transactionId;
     this.customerId = customerId;
     this.productId = productId;
     this.amount = amount;
     // The transaction implicitly uses the cache when it's created or processed.
     ProductDetailsCache.getProductDetails(productId);
 }
 public String getCustomerId() { return customerId; }
 public String getProductId() { return productId; }
 public double getAmount() { return amount; }

 public static Transaction fromCsvLine(String line) {
     String[] parts = line.split(",");
     return new Transaction(parts[0], parts[1], parts[2], Double.parseDouble(parts[3]));
 }
}



