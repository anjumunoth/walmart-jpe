package package1;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public class ProductDetailsCache {
    // This cache grows indefinitely and is never cleared. A classic memory leak.
    private static final Map<String, ProductDetail> cache = new ConcurrentHashMap<>();

    public static ProductDetail getProductDetails(String productId) {
        // If not in cache, create and store it. It's never evicted.
        return cache.computeIfAbsent(productId, id -> {
            System.out.println("   -> Cache MISS for product " + id + ". Loading details...");
            // Simulate loading from a database or a slow service
            try { Thread.sleep(2); } catch (InterruptedException e) {}
            return new ProductDetail(id, "Product Name for " + id, new byte[1024 * 5]); // 5KB of "detail data"
        });
    }
}