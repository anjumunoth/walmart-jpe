package jMeterExample;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
* A thread-safe, singleton class to manage user sessions for the entire application.
* By using a static final map, we guarantee that there is only ONE session store
* across all threads and all object instances within the JVM.
*/
public class SessionManager {

 // The single, globally accessible map for active sessions.
 // 'static' means it belongs to the class, not to an instance.
 // 'final' means the map itself cannot be replaced.
 private static final Map<String, String> activeSessions = new ConcurrentHashMap<>();

 /**
  * Creates a new session for a user and returns the session token.
  * This method is static, so it can be called without creating an instance.
  * @param username The user for whom to create the session.
  * @return The unique session token.
  */
 public static String createSession(String username) {
     String token = "session-" + UUID.randomUUID().toString();
     String cleanToken = token.replaceAll("\\s", "");
     activeSessions.put(cleanToken, username);
     System.out.println("SESSION_MANAGER: Token CREATED & STORED -> '" + cleanToken + "' (Length: " + cleanToken.length() + ")");
     return cleanToken;
      }

 /**
  * Validates if a given token corresponds to an active session, after aggressively
  * sanitizing the input string to remove all forms of whitespace.
  * @param rawToken The potentially "dirty" token received from the client.
  * @return true if the token is valid, false otherwise.
  */
 public static boolean isSessionValid(String rawToken) {
     // Step 1: Basic null/empty check.
     if (rawToken == null || rawToken.isEmpty()) {
         return false;
     }

     // Step 2:
     // Use a regular expression to remove ALL Unicode whitespace characters (\s).
     String sanitizedToken =  rawToken.replaceAll("[^a-z0-9-]", "");

     // Step 3: Use the CLEAN, sanitized token for the lookup.
     boolean isValid = activeSessions.containsKey(sanitizedToken);

     // Step 4: Use the new, detailed logging for debugging if it still fails.
     if (!isValid) {
         System.err.println("--- SESSION VALIDATION FAILED (NEW LOG) ---");
         System.err.println("Raw token received:     '" + rawToken + "' (Length: " + rawToken.length() + ")");
         System.err.println("Sanitized token used:   '" + sanitizedToken + "' (Length: " + sanitizedToken.length() + ")");
         System.err.println("Session map contains it? " + isValid);
         System.err.println("Current map size: " + activeSessions.size());
         System.err.println("-------------------------------------------");
     }
     
     return isValid;
 }
}