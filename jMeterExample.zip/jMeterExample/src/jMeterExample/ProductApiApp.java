package jMeterExample;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class ProductApiApp {

    // The session map is an instance variable. For the built-in HttpServer,
    // the handlers created will correctly share this single instance.
    private final Map<String, String> activeSessions = new ConcurrentHashMap<>();

    // In-memory 'database' of products
    private final List<String> productDatabase = Arrays.asList(
            "Laptop Pro", "Gaming Mouse", "Mechanical Keyboard", "4K Monitor", "USB-C Hub",
            "Wireless Earbuds", "Smart Watch", "Portable SSD", "Webcam HD", "Ergonomic Chair"
    );

    /**
     * The main entry point for the application.
     */
    public static void main(String[] args) throws IOException {
        // Create a single instance of the application and start its server.
        new ProductApiApp().startServer();
    }

    /**
     * Configures and starts the lightweight HTTP server.
     */
    public void startServer() throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8081), 0);
        
        // The handlers are created as inner classes and are bound to this
        // single instance of ProductApiApp, so they share the 'activeSessions' map.
        server.createContext("/api/login", new LoginHandler());
        server.createContext("/api/search", new SearchHandler());
        
        // Use a fixed thread pool for predictable performance under load.
        server.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(10));
        
        System.out.println("Product API server started on port 8081 (Using instance-level session management).");
        server.start();
    }

    // --- HANDLER FOR /api/login ---
    class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equals(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }
            
            String requestBody = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            if (requestBody.contains("\"username\":\"user\"") && requestBody.contains("\"password\":\"pass\"")) {
                
                String rawToken = "session-" + UUID.randomUUID().toString();
                String cleanToken = rawToken.replaceAll("\\s", "");

                activeSessions.put(cleanToken, "user");
                System.out.println("LOGIN HANDLER: Token CREATED & STORED -> '" + cleanToken + "'");
                
                // Send the CLEAN token back to the client.
                String jsonResponse = "{\"status\":\"success\", \"authToken\":\"" + cleanToken + "\"}";
                sendResponse(exchange, 200, jsonResponse);
            } else {
                sendResponse(exchange, 401, "{\"status\":\"error\", \"message\":\"Invalid credentials\"}");
            }
        }
    }

    // --- HANDLER FOR /api/search ---
    class SearchHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String rawToken = exchange.getRequestHeaders().getFirst("X-Auth-Token");

            // CRITICAL FIX #2: Aggressively sanitize the incoming token from the client
            // by whitelisting only valid characters. This protects against any corruption.
            String sanitizedToken = "";
            if (rawToken != null) {
                sanitizedToken = rawToken.replaceAll("[^a-zA-Z0-9-]", "");
            }

            // Use the sanitized token for the lookup.
            if (sanitizedToken.isEmpty() || !activeSessions.containsKey(sanitizedToken)) {
                System.err.println("SEARCH HANDLER: VALIDATION FAILED for raw token -> '" + rawToken + "'");
                sendResponse(exchange, 403, "{\"status\":\"error\", \"message\":\"Forbidden: Invalid or missing token\"}");
                return;
            }

            // --- Search logic proceeds if validation passes ---
            String query = exchange.getRequestURI().getQuery();
            String searchTerm = "";
            if (query != null && query.startsWith("term=")) {
                searchTerm = query.substring(5).toLowerCase();
            }
            
            // Simulate a database lookup delay
            try {
                Thread.sleep(50 + (long) (Math.random() * 150));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            final String finalSearchTerm = searchTerm;
            List<String> results = productDatabase.stream()
                    .filter(p -> p.toLowerCase().contains(finalSearchTerm))
                    .collect(Collectors.toList());
                    
            String jsonResponse = "{\"results\": " + results.size() + ", \"matches\": [\"" + String.join("\",\"", results) + "\"]}";
            sendResponse(exchange, 200, jsonResponse);
        }
    }

    /**
     * A helper method to send a standardized HTTP response.
     * @param exchange The HttpExchange object.
     * @param statusCode The HTTP status code to send.
     * @param response The response body as a string.
     */
    private void sendResponse(HttpExchange exchange, int statusCode, String response) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(statusCode, response.length());
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(response.getBytes());
        }
    }
}