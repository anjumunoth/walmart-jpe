/**
 * 
 */
/**
 * 
 */
module jMeterExample {
	requires jdk.httpserver;
}