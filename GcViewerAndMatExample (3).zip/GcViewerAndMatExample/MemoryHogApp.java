import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MemoryHogApp {

    // A static map to simulate a memory leak via a cache that is never cleared.
    private static final Map<String, byte[]> leakyCache = new ConcurrentHashMap<>();

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Starting Memory Hog Application...");
        System.out.println("This will simulate high object churn and a memory leak.");
        System.out.println("PID: " + ProcessHandle.current().pid());
        System.out.println("-------------------------------------------------");

        // Run the data processor for a long time to observe GC behavior
        for (int i = 0; i < 1_000_000; i++) {
            processData(i);
            Thread.sleep(10); // Slow down a little to make it observable

            if (i % 100 == 0) {
                System.out.println("Processed " + i + " records. Cache size: " + leakyCache.size());
            }
        }

        System.out.println("Application finished successfully (should not happen in leak scenario).");
    }

    public static void processData(int recordId) {
        // 1. Simulate high object churn (short-lived objects)
        // These objects should be collected quickly by the Minor GC.
        List<String> temporaryData = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            temporaryData.add("Temporary data point " + i + " for record " + recordId);
        }

        // 2. Create the main data object that we are "processing"
        // This is a 1MB byte array to make the memory usage significant.
        byte[] dataPayload = new byte[1024 * 1024]; // 1 MB
        String key = "record_key_" + recordId;

        // 3. The Memory Leak: Every 10th record is put into a "cache" and never removed.
        // These objects will be promoted to the Old Generation and will never be collected.
        if (recordId % 10 == 0) {
            leakyCache.put(key, dataPayload);
            System.out.println("!!! LEAK: Added record " + recordId + " to the leaky cache.");
        }
        
        // At the end of this method, 'temporaryData' and 'dataPayload' (if not cached) 
        // go out of scope and become eligible for garbage collection.
    }
}