import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MemoryHogAppFixed {

    // Define the maximum number of items we want to keep in our cache.
    private static final int MAX_CACHE_SIZE = 50;

    // --- THE FIX ---
    // We use a LinkedHashMap to create a simple LRU (Least-Recently-Used) cache.
    // The 'true' in the constructor enables access-order, but for this simple eviction,
    // insertion-order (the default) is what we need. We override a special method
    // to enforce the size limit.
    private static final Map<String, byte[]> boundedCache = new LinkedHashMap<String, byte[]>(MAX_CACHE_SIZE, 0.75f, false) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, byte[]> eldest) {
            // This method is called after a new element is inserted.
            // If it returns true, the eldest entry in the map is removed.
            // This keeps the map size at or below MAX_CACHE_SIZE.
            return size() > MAX_CACHE_SIZE;
        }
    };

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Starting Memory Hog Application (FIXED)...");
        System.out.println("This version uses a bounded cache to prevent memory leaks.");
        System.out.println("PID: " + ProcessHandle.current().pid());
        System.out.println("-------------------------------------------------");

        for (int i = 0; i < 1_000_000; i++) {
            // We need to synchronize access to the non-thread-safe LinkedHashMap
            synchronized (boundedCache) {
                processData(i);
            }
            Thread.sleep(10);

            if (i % 100 == 0) {
                // The cache size should now hover around 50.
                System.out.println("Processed " + i + " records. Cache size: " + boundedCache.size());
            }
        }
        
        System.out.println("Application finished successfully!");
    }

    public static void processData(int recordId) {
        // 1. High object churn (this part is unchanged)
        List<String> temporaryData = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            temporaryData.add("Temporary data point " + i + " for record " + recordId);
        }

        // 2. Main data object (unchanged)
        byte[] dataPayload = new byte[1024 * 1024]; // 1 MB
        String key = "record_key_" + recordId;

        // 3. The Memory Leak behavior is now controlled
        if (recordId % 10 == 0) {
            boundedCache.put(key, dataPayload); // Add to cache, potentially evicting the oldest entry.
            // No more "LEAK" message, as this is now intended behavior.
        }
    }
}