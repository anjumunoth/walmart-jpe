package com.example.demo;


import org.springframework.web.bind.annotation.*;
import java.util.*;
import java.util.concurrent.*;

@RestController
@RequestMapping("/fix")
public class MemoryLeakFixes {

    private static List<byte[]> listLeak = MemoryLeakExamples.listLeak;
    private static List<Object> innerClassLeak = MemoryLeakExamples.innerClassLeak;
    private static ThreadLocal<byte[]> threadLocalLeak = MemoryLeakExamples.threadLocalLeak;
    private static Map<String, byte[]> unboundedCache = MemoryLeakExamples.unboundedCache;
    private static List<Runnable> listenerLeak = MemoryLeakExamples.listenerLeak;
    private static List<ClassLoader> classLoaderLeak = MemoryLeakExamples.classLoaderLeak;
    private static Map<Object, byte[]> strongKeyMap = MemoryLeakExamples.strongKeyMap;
    private static Set<Set<Object>> selfReferencingSet = MemoryLeakExamples.selfReferencingSet;

    @GetMapping("/list")
    public String fixListLeak() {
        listLeak.clear(); // Fix: Clear the list to free memory
        return "List leak fixed: Cleared list";
    }

    @GetMapping("/inner")
    public String fixInnerClassLeak() {
        innerClassLeak.clear(); // Fix: Clear all references from the list
        return "Inner class leak fixed: Cleared list";
    }

    @GetMapping("/threadlocal")
    public String fixThreadLocalLeak() {
        threadLocalLeak.remove(); // Fix: Always remove when done
        return "ThreadLocal leak fixed: Removed value";
    }

    @GetMapping("/cache")
    public String fixCacheLeak() {
        unboundedCache.clear(); // Fix: Use size-limited caches like Caffeine or LRU cache
        return "Cache leak fixed: Cleared cache";
    }

    @GetMapping("/listeners")
    public String fixListenerLeak() {
        listenerLeak.clear(); // Fix: Properly unregister listeners when no longer needed
        return "Listener leak fixed: Cleared listeners";
    }

    @GetMapping("/classloader")
    public String fixClassLoaderLeak() {
        classLoaderLeak.clear(); // Fix: Clear references when no longer used
        return "ClassLoader leak fixed: Cleared class loaders";
    }

    @GetMapping("/strongkey")
    public String fixStrongKeyLeak() {
        strongKeyMap.clear(); // Fix: Use WeakHashMap for automatic key cleanup
        return "Strong key map leak fixed: Cleared map";
    }

    @GetMapping("/selfref")
    public String fixSelfReferenceLeak() {
        selfReferencingSet.clear(); // Fix: Break cyclic references and clear holding collection
        return "Self-referencing leak fixed: Cleared sets";
    }
}
