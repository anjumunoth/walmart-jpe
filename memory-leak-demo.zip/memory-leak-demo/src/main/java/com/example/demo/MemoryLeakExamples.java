package com.example.demo;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.net.URLClassLoader;
import java.util.*;
import java.util.concurrent.*;

@SpringBootApplication
@RestController
@RequestMapping("/leak")
public class MemoryLeakExamples {

    public static void main(String[] args) {
        SpringApplication.run(MemoryLeakExamples.class, args);
    }

    public static List<byte[]> listLeak = new ArrayList<>();
    public static List<Object> innerClassLeak = new ArrayList<>();
    public static ThreadLocal<byte[]> threadLocalLeak = new ThreadLocal<>();
    public static final Map<String, byte[]> unboundedCache = new ConcurrentHashMap<>();
    public static final List<Runnable> listenerLeak = new ArrayList<>();
    public static final List<ClassLoader> classLoaderLeak = new ArrayList<>();
    public static final Map<Object, byte[]> strongKeyMap = new HashMap<>();
    public static final Set<Set<Object>> selfReferencingSet = new HashSet<>();

    @GetMapping("/list")
    public String listLeak() {
        listLeak.add(new byte[10 * 1024 * 1024]);
        return "List leak triggered";
    }

    class InnerLeakyClass {
        private byte[] data = new byte[10 * 1024 * 1024];
    }

    @GetMapping("/inner")
    public String innerClassLeak() {
        innerClassLeak.add(new InnerLeakyClass());
        return "Inner class leak triggered";
    }

    @GetMapping("/threadlocal")
    public String threadLocalLeak() {
        threadLocalLeak.set(new byte[10 * 1024 * 1024]);
        return "ThreadLocal leak triggered";
    }

    @GetMapping("/cache")
    public String cacheLeak() {
        unboundedCache.put(UUID.randomUUID().toString(), new byte[10 * 1024 * 1024]);
        return "Cache leak triggered";
    }

    @GetMapping("/listeners")
    public String listenerLeak() {
        listenerLeak.add(() -> System.out.println("Leak Event"));
        return "Listener leak triggered";
    }

    @GetMapping("/classloader")
    public String classLoaderLeak() {
        try {
            URLClassLoader loader = new URLClassLoader(new java.net.URL[0], this.getClass().getClassLoader());
            classLoaderLeak.add(loader);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "ClassLoader leak triggered";
    }

    @GetMapping("/strongkey")
    public String strongKeyLeak() {
        Object key = new Object();
        strongKeyMap.put(key, new byte[10 * 1024 * 1024]);
        return "Strong key map leak triggered";
    }

    @GetMapping("/selfref")
    public String selfReferenceLeak() {
        Set<Object> set = new HashSet<>();
        set.add(set);
        selfReferencingSet.add(set);
        return "Self-referencing object leak triggered";
    }

    @GetMapping("/memory")
    public String memoryStatus() {
        Runtime runtime = Runtime.getRuntime();
        
        long usedMemory = runtime.totalMemory() - runtime.freeMemory();
        return "Used Memory: " + (usedMemory / (1024 * 1024)) + " MB; free memory :"+(runtime.freeMemory() / (1024 * 1024)) + " MB";
    }
    // Fallback for undefined endpoints within this controller
    @RequestMapping("/**")
    public ResponseEntity<String> fallback() {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Endpoint not found. Please check the URL.");
    }
}
