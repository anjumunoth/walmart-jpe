package badCpuUsageDemo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

/**
 * An interactive, menu-driven demonstration of CPU usage differences between
 * efficient and inefficient algorithms. The user can choose which validation
 * to run and see the performance impact directly.
 */
public class BadCpuUsageDemo {

    // These are instance variables, not static. They are "owned" by the application instance.
    private final List<Product> products;
    private final List<String> denylistedCategoriesAsList;
    private final Set<String> denylistedCategoriesAsSet;

    // Validators are created once and reused.
    private final InefficientDataValidator inefficientValidator;
    private final EfficientDataValidator efficientValidator;

    /**
     * The main entry point. It creates an application instance and runs it.
     */
    public static void main(String[] args) {
        // Create an instance of the application to keep logic non-static.
        BadCpuUsageDemo demo = new BadCpuUsageDemo();
        demo.run();
    }

    /**
     * Constructor sets up the data needed for the demo.
     */
    public BadCpuUsageDemo() {
        System.out.println("Generating test data, please wait...");
        // Use a large dataset to make the performance difference stark.
        this.products = generateProducts(5_000_000);
        this.denylistedCategoriesAsList = generateDenylist(1000);
        this.denylistedCategoriesAsSet = new HashSet<>(this.denylistedCategoriesAsList);
        System.out.println("Data generation complete. Ready to run.");

        // Instantiate the validators once.
        this.inefficientValidator = new InefficientDataValidator(this.denylistedCategoriesAsList);
        this.efficientValidator = new EfficientDataValidator(this.denylistedCategoriesAsSet);
    }

    /**
     * The main interactive loop for the user.
     */
    public void run() {
        try (Scanner scanner = new Scanner(System.in)) {
            boolean running = true;
            while (running) {
                printMenu();
                System.out.print("Enter your choice: ");
                String choice = scanner.nextLine().trim();

                switch (choice) {
                    case "1":
                        runInefficientValidation();
                        break;
                    case "2":
                        runEfficientValidation();
                        break;
                    case "3":
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter 1, 2, or 3.");
                        break;
                }
            }
        }
        System.out.println("Exiting demo.");
    }

    private void printMenu() {
        System.out.println("\n--- CPU Usage Profiling Menu ---");
        System.out.println("1. Run IN-EFFICIENT Validation (High CPU Usage)");
        System.out.println("2. Run EFFICIENT Validation (Low CPU Usage)");
        System.out.println("3. Exit");
        System.out.println("--------------------------------");
    }

    private void runInefficientValidation() {
        System.out.println("\nStarting IN-EFFICIENT validation. This will take several seconds...");
        System.out.println("... (Start your profiler now if you want to capture this run) ...");
        long startTime = System.nanoTime();
        
        long validCount = this.products.stream()
                .filter(p -> this.inefficientValidator.isProductValid(p.sku, p.category))
                .count();

        long endTime = System.nanoTime();
        System.out.println("\n--- IN-EFFICIENT RUN COMPLETE ---");
        System.out.printf("  Time taken: %.2f seconds%n", (endTime - startTime) / 1_000_000_000.0);
        System.out.printf("  Valid products found: %d%n", validCount);
        System.out.println("----------------------------------");
    }
    
    private void runEfficientValidation() {
        System.out.println("\nStarting EFFICIENT validation. This will be very fast...");
        long startTime = System.nanoTime();
        
        long validCount = this.products.stream()
                .filter(p -> this.efficientValidator.isProductValid(p.sku, p.category))
                .count();

        long endTime = System.nanoTime();
        System.out.println("\n--- EFFICIENT RUN COMPLETE ---");
        System.out.printf("  Time taken: %.4f seconds%n", (endTime - startTime) / 1_000_000_000.0);
        System.out.printf("  Valid products found: %d%n", validCount);
        System.out.println("--------------------------------");
    }


    // --- Helper methods to generate sample data (Unchanged) ---
    private List<String> generateDenylist(int count) {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            list.add("Category-" + i);
        }
        return list;
    }

    private List<Product> generateProducts(int count) {
        List<Product> list = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String sku = "ABC-" + (100000 + i) + "-xyz";
            String category = "Category-" + (i % 2000); // Some will be on denylist, some not
            list.add(new Product(sku, category));
        }
        return list;
    }

    static class Product {
        final String sku;
        final String category;
        Product(String sku, String category) { this.sku = sku; this.category = category; }
    }
}