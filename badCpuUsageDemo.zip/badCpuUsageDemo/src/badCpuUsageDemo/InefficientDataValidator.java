package badCpuUsageDemo;

import java.util.List;
import java.util.regex.Pattern;

public class InefficientDataValidator {
 // Instance variable, not static. This list is searched inefficiently.
 private final List<String> denylistedCategories;

 public InefficientDataValidator(List<String> denylistedCategories) {
     this.denylistedCategories = denylistedCategories;
     System.out.println("InefficientDataValidator created with " + denylistedCategories.size() + " denylisted categories.");
 }

 /**
  * Validates a product SKU and its category. THIS IS THE INEFFICIENT METHOD.
  */
 public boolean isProductValid(String sku, String category) {
     // PROBLEM 1: Regex Compilation inside the method.
     // Pattern.compile() is a very expensive operation. Doing it for every
     // single validation call is a huge waste of CPU.
     String skuRegex = "^[A-Z]{2,4}-[0-9]{5,7}-[a-z]{3}$";
     if (!Pattern.compile(skuRegex).matcher(sku).matches()) {
         return false;
     }

     // PROBLEM 2: Linear search on a List inside a loop.
     // list.contains() on an ArrayList is an O(n) operation. If this method is called
     // thousands of times, and the denylist is large, this becomes a major bottleneck.
     if (denylistedCategories.contains(category)) {
         return false;
     }

     return true;
 }
}