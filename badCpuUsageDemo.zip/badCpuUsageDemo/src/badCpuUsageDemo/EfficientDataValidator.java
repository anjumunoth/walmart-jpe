package badCpuUsageDemo;

import java.util.Set;
import java.util.regex.Pattern;

public class EfficientDataValidator {
 // SOLUTION 1: Compile the pattern once and store it as an instance field.
 private final Pattern skuPattern = Pattern.compile("^[A-Z]{2,4}-[0-9]{5,7}-[a-z]{3}$");

 // SOLUTION 2: Use a HashSet for fast O(1) average-time lookups.
 private final Set<String> denylistedCategoriesSet;

 public EfficientDataValidator(Set<String> denylistedCategories) {
     this.denylistedCategoriesSet = denylistedCategories;
     System.out.println("EfficientDataValidator created with " + denylistedCategories.size() + " denylisted categories.");
 }

 /**
  * Validates a product SKU and its category. THIS IS THE EFFICIENT METHOD.
  */
 public boolean isProductValid(String sku, String category) {
     // Use the pre-compiled pattern.
     if (!skuPattern.matcher(sku).matches()) {
         return false;
     }

     // Use the HashSet for a near-instant lookup.
     if (denylistedCategoriesSet.contains(category)) {
         return false;
     }

     return true;
 }
}