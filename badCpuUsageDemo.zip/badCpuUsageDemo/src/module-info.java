/**
 * 
 */
/**
 * 
 */
module badCpuUsageDemo {
}