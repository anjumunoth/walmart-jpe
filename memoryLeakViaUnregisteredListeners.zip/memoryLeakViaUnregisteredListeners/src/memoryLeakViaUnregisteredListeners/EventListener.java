package memoryLeakViaUnregisteredListeners;

public interface EventListener {
	 void onEvent(String eventData);
	}

