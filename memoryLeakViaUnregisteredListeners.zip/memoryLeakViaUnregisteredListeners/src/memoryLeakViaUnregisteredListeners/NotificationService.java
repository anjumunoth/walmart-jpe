package memoryLeakViaUnregisteredListeners;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NotificationService {
 // This map is the problem area. It will hold references to listeners.
 // It's an instance variable, not static.
 private final Map<String, List<EventListener>> customers;

 public NotificationService() {
     this.customers = new ConcurrentHashMap<>();
     System.out.println("NotificationService created.");
 }

 public void subscribe(String eventType, EventListener listener) {
     customers.computeIfAbsent(eventType, k -> new ArrayList<>()).add(listener);
     System.out.println(listener.getClass().getSimpleName() + " subscribed to " + eventType);
 }

 // THE MISSING PIECE: There is no 'unsubscribe' method, which is the root cause of the leak.
 /*
 public void unsubscribe(String eventType, EventListener listener) {
     if (customers.containsKey(eventType)) {
         customers.get(eventType).remove(listener);
     }
 }
 */

 public void sendNotification(String eventType, String data) {
     if (customers.containsKey(eventType)) {
         customers.get(eventType).forEach(listener -> listener.onEvent(data));
     }
 }

 public int getListenerCount() {
     return (int) customers.values().stream().mapToLong(List::size).sum();
 }
}
