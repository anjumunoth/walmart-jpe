package memoryLeakViaUnregisteredListeners;

//MemoryLeakDemo.java
public class MemoryLeakDemo {

 public static void main(String[] args) throws InterruptedException {
     // This NotificationService is the long-lived object.
     // In a real app, it might be managed by a dependency injection framework.
     NotificationService notificationService = new NotificationService();

     System.out.println("Starting simulation. Monitor heap memory with a profiler (e.g., VisualVM).");
     System.out.println("You will see the heap size steadily increase and never go down.");

     int requestIdCounter = 0;
     while (true) {
         // Simulate processing a new web request or task.
         // A new RequestProcessor is created for each task.
         RequestProcessor processor = new RequestProcessor("req-" + requestIdCounter++, notificationService);

         // In a real scenario, the 'processor' object would go out of scope here
         // and should be eligible for garbage collection.
         // But because it subscribed to NotificationService, it will leak.

         System.out.println("Current active listeners: " + notificationService.getListenerCount());
         Thread.sleep(100); // Slow down the loop to make it observable

         if (requestIdCounter % 10 == 0) {
              // Suggest a GC run, though it won't be able to collect the leaked objects.
             System.gc();
             System.out.println("GC suggested. Leaked objects will remain.");
         }
     }
 }
}