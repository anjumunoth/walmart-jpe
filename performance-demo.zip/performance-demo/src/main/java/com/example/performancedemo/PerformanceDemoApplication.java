
package com.example.performancedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerformanceDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(PerformanceDemoApplication.class, args);
    }
}


/*
 * Run the Application
Open a terminal in your project's root directory and run:

mvn spring-boot:run
 */
