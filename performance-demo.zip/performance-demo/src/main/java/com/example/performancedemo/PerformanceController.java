package com.example.performancedemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PerformanceController {

    private final ProductService productService;

    public PerformanceController(ProductService productService) {
        this.productService = productService;
    }

    // === Problematic Endpoints ===

    @GetMapping("/problem/cpu")
    public String getCpuIntensive() {
        return productService.calculateProductScoreSlowly();
    }

    @GetMapping("/problem/memory-churn")
    public String getMemoryChurn() {
        return productService.generateLargeReportSlowly();
    }

    @GetMapping("/problem/blocking-io")
    public String getBlockingIo() throws InterruptedException {
        return productService.fetchExternalDataSlowly();
    }

    @GetMapping("/problem/memory-leak/{term}")
    public String getMemoryLeak(@PathVariable String term) {
        return productService.logSearchTerm(term);
    }

    // === Optimized Endpoints ===

    @GetMapping("/fixed/cpu")
    public String getCpuFixed() {
        return productService.calculateProductScoreQuickly();
    }

    @GetMapping("/fixed/memory-churn")
    public String getMemoryChurnFixed() {
        return productService.generateLargeReportEfficiently();
    }

    @GetMapping("/fixed/blocking-io")
    public String getBlockingIoFixed() {
        return productService.fetchExternalDataQuickly();
    }
    
    @GetMapping("/fixed/clear-leak")
    public String clearMemoryLeak() {
        return productService.clearSearchHistory();
    }
}