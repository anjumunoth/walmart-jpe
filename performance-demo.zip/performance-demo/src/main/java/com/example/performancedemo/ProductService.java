package com.example.performancedemo;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ProductService {

    // A static map to demonstrate a memory leak
    private static final Map<String, String> searchHistoryCache = new ConcurrentHashMap<>();

    // --- 1. CPU Intensive Bottleneck ---
    public String calculateProductScoreSlowly() {
        // Simulates a very complex, inefficient algorithm
        for (long i = 0; i < 200_000_000L; i++) {
            Math.sqrt(i); // Dummy work
        }
        return "Slow calculation finished.";
    }

    public String calculateProductScoreQuickly() {
        // The "fix" is a more efficient algorithm (or in this case, a trivial one)
        return "Quick calculation finished.";
    }

    // --- 2. Memory Churn Bottleneck ---
    public String generateLargeReportSlowly() {
        String report = "";
        for (int i = 0; i < 50_000; i++) {
            report += " Report line " + i + "\n"; // Creates a new String object in every loop
        }
        return report;
    }

    public String generateLargeReportEfficiently() {
        StringBuilder report = new StringBuilder();
        for (int i = 0; i < 50_000; i++) {
            report.append(" Report line ").append(i).append("\n");
        }
        return report.toString();
    }

    // --- 3. Blocking I/O Bottleneck ---
    public String fetchExternalDataSlowly() throws InterruptedException {
        // Simulates waiting for a slow database or external microservice
        Thread.sleep(5000); // Blocks the request thread for 5 seconds
        return "Data fetched after 5 seconds.";
    }

    public String fetchExternalDataQuickly() {
        // The fix is a faster external system, or using non-blocking I/O
        return "Data fetched instantly.";
    }

    // --- 4. Memory Leak Bottleneck ---
    public String logSearchTerm(String term) {
        // Problem: This map grows indefinitely, as nothing is ever removed.
        // This is a classic memory leak.
        searchHistoryCache.put(term + System.nanoTime(), term);
        return "Term '" + term + "' logged. Cache size: " + searchHistoryCache.size();
    }

    public String clearSearchHistory() {
        int size = searchHistoryCache.size();
        searchHistoryCache.clear();
        return "Cleared cache. " + size + " items were removed.";
    }
}