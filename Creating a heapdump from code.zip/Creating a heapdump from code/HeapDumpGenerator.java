import com.sun.management.HotSpotDiagnosticMXBean;
import javax.management.MBeanServer;
import java.io.IOException;
import java.lang.management.ManagementFactory;

public class HeapDumpGenerator {

    /**
     * Programmatically generates a heap dump.
     *
     * @param filePath The path where the heap dump file will be saved.
     * @param live     If true, dumps only live objects (i.e., runs a Full GC first).
     *                 If false, dumps all objects, including unreachable ones.
     *                 For memory leak analysis, 'true' is often more useful.
     */
    public static void createHeapDump(String filePath, boolean live) {
        System.out.println("Generating heap dump at: " + filePath);
        try {
            // Get the MBean server
            MBeanServer server = ManagementFactory.getPlatformMBeanServer();

            // Get the HotSpotDiagnosticMXBean
            HotSpotDiagnosticMXBean mxBean = ManagementFactory.newPlatformMXBeanProxy(
                    server, "com.sun.management:type=HotSpotDiagnostic", HotSpotDiagnosticMXBean.class);

            // Call the dumpHeap method
            mxBean.dumpHeap(filePath, live);
            
            System.out.println("Heap dump successfully created.");
        } catch (IOException e) {
            System.err.println("Error creating heap dump: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Example usage:
        // Let's create some objects to make the dump interesting
        java.util.List<String> leakyList = new java.util.ArrayList<>();
        for (int i = 0; i < 100_000; i++) {
            leakyList.add("This is a sample string to fill up the heap: " + i);
        }

        // Define the file path. Using a timestamp is a good practice.
        String dumpFile = "heapdump-" + System.currentTimeMillis() + ".hprof";
        
        // Create the heap dump. Set 'live' to true to see what the GC can't collect.
        createHeapDump(dumpFile, true);
        
        // Keep the application running for a moment to confirm dump creation
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}